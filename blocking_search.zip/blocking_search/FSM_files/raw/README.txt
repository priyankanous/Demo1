== This is the Readme file for folder LatestVA ==

In LatestVA, we have the models for all variables used in pentry.c. 
Among all variables, 24 are used in the no-trunk model and 6 are trunk-related and have been moved to the folder called "Trunk":

cmd_t.fsm is the cmd_v4.fsm with no-trunk assumption
